<x-base.leaflet-map-loader
    lat="-6.2425342"
    long="106.8626478"
    apiKey=""
    {{ $attributes->merge($attributes->whereDoesntStartWith('class')->getAttributes()) }}
/>